import datetime
import pymysql

# Database connection
connection = pymysql.connect(
    host='localhost',
    user='root',  # Default username for XAMPP
    password='',  # Default password for XAMPP
    database='vehicle_details'
)
cursor = connection.cursor()

# Function to calculate parking charges based on duration slabs
def calculate_charges(ticket_number):
    try:
        # Fetch entry time from the database
        sql_fetch = "SELECT entry_time, entry_date FROM parking_tickets WHERE ticket_number = %s AND status = 'active'"
        cursor.execute(sql_fetch, (ticket_number,))
        result = cursor.fetchone()

        if result:
            entry_time_str = result[0]  # Entry time as string
            entry_date_str = result[1]  # Entry date as string

            # Convert entry time and date to datetime object
            entry_datetime = datetime.datetime.strptime(f"{entry_date_str} {entry_time_str}", "%Y-%m-%d %H:%M:%S")

            # Get current time
            current_datetime = datetime.datetime.now()

            # Calculate parking duration in minutes
            duration_minutes = (current_datetime - entry_datetime).total_seconds() / 60  # Convert seconds to minutes

            # Calculate bill amount based on duration slabs
            if duration_minutes <= 60:
                bill_amount = 10
            elif duration_minutes <= 120:
                bill_amount = 20
            elif duration_minutes <= 180:
                bill_amount = 30
            else:
                bill_amount = 50

            # Update database with exit time and bill amount
            sql_update = """
                UPDATE parking_tickets
                SET exit_time = %s, amount = %s, status = 'completed'
                WHERE ticket_number = %s
            """
            cursor.execute(sql_update, (current_datetime.strftime("%H:%M:%S"), bill_amount, ticket_number))
            connection.commit()

            # Display the bill details
            print(f"Parking Duration: {duration_minutes:.2f} minutes")
            print(f"Bill Amount: ₹{bill_amount}")
            print(f"Exit Time: {current_datetime.strftime('%H:%M:%S')}")

        else:
            print("Invalid ticket or already processed.")

    except Exception as e:
        print("An error occurred:", str(e))

# Example usage
ticket_number = input("Enter scanned ticket number: ")  # Simulate scanning the QR code
calculate_charges(ticket_number)