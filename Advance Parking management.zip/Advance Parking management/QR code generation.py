from tkinter import Tk, Label, Entry, Button
import datetime
import pymysql
import qrcode
from PIL import ImageTk, Image  # Needed to display QR code in the GUI
import os  # To manage file operations and printing

# Database connection
connection = pymysql.connect(
    host='localhost',
    user='root',  # Default username for XAMPP
    password='',  # Default password for XAMPP
    database='vehicle_details'
)
cursor = connection.cursor()

# Function to print the QR code
def print_qr(ticket_number):
    try:
        # Define the temporary filename for QR code
        temp_filename = f"{ticket_number}_print.png"
        qr_img.save(temp_filename)  # Save the QR code temporarily

        # Print the QR code using the default image viewer (works on most operating systems)
        os.startfile(temp_filename, "print")  # This triggers the print command

        print("QR Code sent to printer successfully!")

        # Optionally delete the temporary file after printing (comment this out if you need the file)
        os.remove(temp_filename)
    except Exception as e:
        print("An error occurred while printing:", str(e))

# Submit function
def submit_form():
    vehicle_number = vehicle_number_entry.get()
    name = name_entry.get()
    current_time = datetime.datetime.now()
    entry_time = current_time.strftime("%H:%M:%S")
    entry_date = current_time.strftime("%Y-%m-%d")

    try:
        # Ensure entry_time and entry_date are properly formatted
        ticket_number = f"{vehicle_number}_{entry_date}_{entry_time.replace(':', '-')}"  # Sanitize filename

        # Insert data into the database with proper handling
        sql = """
            INSERT INTO parking_tickets (ticket_number, user_id, entry_time, entry_date, amount, status) 
            VALUES (%s, %s, %s, %s, %s, %s)
        """
        cursor.execute(sql, (ticket_number, name, entry_time, entry_date, None, 'active'))
        connection.commit()

        # Generate QR code with embedded details
        qr_data = f"Vehicle Number: {vehicle_number}\nName: {name}\nEntry Time: {entry_time}\nEntry Date: {entry_date}\nTicket Number: {ticket_number}"
        global qr_img
        qr = qrcode.QRCode(
            version=1,  # Controls the overall size of the QR code grid
            error_correction=qrcode.constants.ERROR_CORRECT_L,  # Lower error correction for more data capacity
            box_size=4,  # Reduced size of each box in the QR code (smaller QR code)
            border=2  # Reduced border size
        )
        qr.add_data(qr_data)
        qr.make(fit=True)

        # Generate the QR code image with resized dimensions
        qr_img = qr.make_image(fill_color="black", back_color="white")

        # Display the QR code in the GUI (without saving)
        qr_image = ImageTk.PhotoImage(image=qr_img)
        qr_label = Label(root, image=qr_image)
        qr_label.image = qr_image  # Keep a reference to avoid garbage collection
        qr_label.grid(row=5, column=0, columnspan=2)

        # Add Print Button
        print_button = Button(root, text="Print QR", command=lambda: print_qr(ticket_number))
        print_button.grid(row=6, column=0, columnspan=2, pady=10)

        # Confirmation message
        print("Details submitted successfully!")
        print("Vehicle Number:", vehicle_number)
        print("Name:", name)
        print("Entry Time:", entry_time)
        print("Entry Date:", entry_date)

    except Exception as e:
        print("An error occurred:", str(e))

# Create main window
root = Tk()
root.title("Parking Entry Form")

# Create form labels and entries
Label(root, text="Vehicle Number").grid(row=0, column=0, padx=10, pady=5)
vehicle_number_entry = Entry(root)
vehicle_number_entry.grid(row=0, column=1, padx=10, pady=5)

Label(root, text="Name").grid(row=1, column=0, padx=10, pady=5)
name_entry = Entry(root)
name_entry.grid(row=1, column=1, padx=10, pady=5)

Label(root, text="Entry Time (Fetched Automatically)").grid(row=2, column=0, padx=10, pady=5)
Label(root, text="Entry Date (Fetched Automatically)").grid(row=3, column=0, padx=10, pady=5)

# Add Submit Button
submit_button = Button(root, text="Submit", command=submit_form)
submit_button.grid(row=4, column=0, columnspan=2, pady=10)

# Add Exit Button
exit_button = Button(root, text="Exit", command=root.destroy)
exit_button.grid(row=7, column=0, columnspan=2, pady=10)

# Start the GUI loop
root.mainloop()